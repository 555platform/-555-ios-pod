//
//  RNBackgroundTimer.h
//  react-native-background-timer
//
//  Created by IjzerenHein on 06-09-2016.
//  Copyright (c) ATO Gear. All rights reserved.
//

#import <React/RCTBridgeModule.h>
#import "RCTEventEmitter.h"

@interface RNBackgroundTimer : RCTEventEmitter <RCTBridgeModule>

@end
