//
//  RtcReactSdk.swift
//  RtcReactSdk
//
//  Created by Admin on 13/11/19.
//  Copyright © 2019 Admin. All rights reserved.
//

import UIKit
import React
/**
* Input for setting Loglevel of sdk
*/
public enum RtcLogLevel : Int{
    case none = 0
    case error = 1
    case warning = 2
    case info = 3
    case debug = 4
    case verbose = 5
}

/**
* The ``Rtc555Sdk`` class is used to initialize sdk, set mandatory config for rtcconnection and also to set loglevel of sdk
*/
public class Rtc555Sdk {
    /**
    * sharedInstance of Rtc555Sdk
    */
    public static let sharedInstance = Rtc555Sdk()
    /**
    * Delegate object of Rtc555SdkDelegate to receive onnotification callback
    */
    public static var rtcSdkDelegate : Rtc555SdkDelegate!
    var config: Rtc555Config?
    init(){}
    /**
     * returns Rtc555Config object
     */
    public func getConfig() -> Rtc555Config{
        if config == nil {
            config = Rtc555Config()
        }
        return config!
    }
    /**
     This method is used to set mandatory config parameters which is passed as Rtc555Config object for rtcconnection
      - Parameters:
           - config: Rtc555Config object
    */
    public static func setConfig(config Config:Rtc555Config){
        var config : [String : Any] = [:]
        config["sourceTelephonenum"] = Config.phoneNumber
        config["routingId"] = Config.routingId
        config["eventManagerUrl"] = Config.url
        config["token"] = Config.token
        config["todomain"] = Config.domain
        config["enableReconnect"] = Config.enableReconnect
        config["notificationManagerUrl"] = Config.notificationManagerUrl
        let bundle:Bundle = Bundle(for:self)
        let resourcePath = bundle.path(forResource: "dialtone", ofType: "mp3")
        config["path"] = resourcePath;
        let args = [config]
        RtcReactBridge.sharedInstance.callMethod("setConfig","Rtc555Sdk",args)
    }
    /**
       This method is callled to initialize sdk
    */
    public static func initializeLibrary() {
        RtcReactBridge.sharedInstance.createBridge()
    }
    /**
       This method is callled to set loglevels of sdk
    */
    public static func setLoglevel(logLevel level:RtcLogLevel){
          let args = [level.rawValue]
          Rtc555Logger.logLevel = level
          RtcReactBridge.sharedInstance.callMethod("setLogLevel","Rtc555Sdk",args)
    }
    /**
       This method is callled to disconnect rtc connection
    */
    public static func cleanup(){
        let args:[String] = []
        RtcReactBridge.sharedInstance.callMethod("cleanup","Rtc555Sdk",args)
    }

}

/**
* Rtc555CallDelegate is used to send callbacks for call status and error
*/
public protocol Rtc555CallDelegate {
    /**
      onStatus is called with status and callid of call
     - Parameters:
          - status: callstatus
          - id: call id of call
    */
    func onStatus(status callStatus:CallStatus,id callId:String)
    /**
      onError is called with error info and callid of call
     - Parameters:
          - error: contains error info
          - id: call id of call
    */
    func onError(error errorInfo:Error,id callId:String)
}


/**
* Rtc555SdkDelegate is used to send callback for xmpp notification
*/
public protocol Rtc555SdkDelegate{
   /**
    onNotification is called when xmpp notification is received
     - Parameters:
          - notification: notificationdata
   */
   func onNotification(notification notificationData: [AnyHashable : Any])
}







