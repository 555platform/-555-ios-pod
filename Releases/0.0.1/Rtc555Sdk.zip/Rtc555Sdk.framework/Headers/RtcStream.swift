//
//  RtcStream.swift
//  RtcReactSdk
//
//  Created by Girish on 10/01/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import Foundation

/**
* The ``RtcStream`` class is used in saving stream data 
*/
public class RtcStream: NSObject {
    /**
    * mediaStream object to save steam data
    */
    public var mediaStream:[String:Any] = [:]    
}


