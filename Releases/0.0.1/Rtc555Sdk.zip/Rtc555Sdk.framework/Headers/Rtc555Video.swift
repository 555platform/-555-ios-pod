//
//  Rtc555Video.swift
//  Rtc555Sdk
//
//  Created by Girish on 23/03/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import Foundation

/**
* The ``Rtc555Video`` is a class used to create and manage the video call
*
* This class provides the following apis
*
* 1) api  call(targetEmailId,notificationPayload,stream)  can be used for creating session.creating session  involves in getting the room Id from  backend by REST API call and creates session using room id.
*
* 2) api  accept(notificationData,stream)  can be used for joining session.Joining session  involves in joining the room using room id which is recieved in notification.
*
*  3) api createStream(callType) can be used to creatstream
*
* 4)  api hangup(callId)  used to close session
*/
public class Rtc555Video: NSObject {
    /**
    * Delegate object of Rtc555VideoDelegate to receive  callbacks
    */
   internal static var rtcVideoDelegate : Rtc555VideoDelegate!
   static var isCallSuccess:Bool?
   static var callId:String?
   static var isCallFailed:Bool?
   static var sessionError:Error?
   static var streamDict = [String:RtcStream]()
   /**
      This method is called to create and start video session which involves getting the room id from server and creating the room using the room id.
      - Parameters:
           - targetEmailID : telephone emailid of participant
           - notificationPayload: notificationData
           - stream : stream of type RtcSteam
           - completion: returns enum result. Success case of result will return callid .failure case return error information.
   */
    public static func call(targetEmailID targetid:String,notificationPayload notificationpayload:[AnyHashable : Any],streamId Streamid:String,rtcVideoDelegate videoDelegate:Rtc555VideoDelegate, completion: @escaping (Result<String, Error>) -> Void) {
        RtcReactBridge.sharedInstance.callType = "Videocall"
        var stream = RtcStream()
        if(!Streamid.isEmpty && !Rtc555Video.streamDict.isEmpty){
            if(Rtc555Video.streamDict[Streamid] != nil){
                stream = Rtc555Video.streamDict[Streamid]!
            }
        }
        let jsonData = try! JSONSerialization.data(withJSONObject: stream.mediaStream as Any, options: [])
        let streamData = String(data: jsonData, encoding: .utf8)!
//        var notificationData = ""
//        do{
//            let jsonData = try JSONSerialization.data(withJSONObject: notificationpayload, options: JSONSerialization.WritingOptions.prettyPrinted)
//
//            notificationData = String(data: jsonData, encoding: String.Encoding.utf8)!
//        }catch {
//            Rtc555Logger.e("Error creating notification payload")
//        }
       
        let args = [targetid,notificationpayload,streamData] as [Any]
        RtcReactBridge.sharedInstance.callMethod("call","Rtc555Video",args)
    
        DispatchQueue.main.async {
            Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { (timer) in
                var result: Result<String, Error>
                if(!RtcReactBridge.sharedInstance.isBridgeInitializing){
                    let error =  NSError(domain:"", code:-901, userInfo:[ NSLocalizedDescriptionKey:"sdk not initialized"])
                    result = .failure(error)
                    completion(result)
                    timer.invalidate()
                }
                if Rtc555Video.isCallSuccess ?? false{
                   Rtc555Video.isCallSuccess = false
                   result = .success(Rtc555Video.self.callId!)
                   RtcReactBridge.sharedInstance.callDelegateMap[Rtc555Video.self.callId!] = videoDelegate
                   completion(result)
                   timer.invalidate()
                }else if Rtc555Video.isCallFailed ?? false{
                   Rtc555Video.isCallFailed = false
                   result = .failure(Rtc555Video.self.sessionError!)
                   completion(result)
                   timer.invalidate()
            }
        }
      }
    }
    /**
       This method is called to join video session which involves getting the room id from server and creating the room using the room id.
       - Parameters:
            - notificationData: notificationData
            - stream : stream of type RtcSteam
            - completion: returns enum result. Success case of result will return callid .failure case return error information.
    */
   public static func accept(notificationData notification:[AnyHashable : Any],streamId Streamid:String,rtcVideoDelegate videoDelegate:Rtc555VideoDelegate,completion: @escaping (Result<String, Error>) -> Void) {
    
        RtcReactBridge.sharedInstance.callType = "Videocall"
        var stream = RtcStream()
        if(!Streamid.isEmpty && !Rtc555Video.streamDict.isEmpty){
            if(Rtc555Video.streamDict[Streamid] != nil){
                stream = Rtc555Video.streamDict[Streamid]!
            }
        }
        let jsonData = try! JSONSerialization.data(withJSONObject: stream.mediaStream as Any, options: [])
        let streamData = String(data: jsonData, encoding: .utf8)!

        let args = [notification,streamData] as [Any]
        RtcReactBridge.sharedInstance.callMethod("accept","Rtc555Video",args)
        DispatchQueue.main.async {
            Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { (timer) in
                var result: Result<String, Error>
                if(!RtcReactBridge.sharedInstance.isBridgeInitializing){
                    let error =  NSError(domain:"", code:-901, userInfo:[ NSLocalizedDescriptionKey:"sdk not initialized"])
                    result = .failure(error)
                    completion(result)
                    timer.invalidate()
                }
                Rtc555Logger.i("running timer")
                if Rtc555Video.isCallSuccess ?? false{
                   Rtc555Video.isCallSuccess = false
                   result = .success(Rtc555Video.self.callId!)
                   RtcReactBridge.sharedInstance.callDelegateMap[Rtc555Video.self.callId!] = videoDelegate
                   completion(result)
                   timer.invalidate()
                 }else if Rtc555Video.isCallFailed ?? false{
                   Rtc555Video.isCallFailed = false
                   result = .failure(Rtc555Video.self.sessionError!)
                   completion(result)
                   timer.invalidate()
                 }
             }
        }
    }
    /**
        This method is called to join video session which involves getting the room id from server and creating the room using the room id.
        - Parameters:
             - notificationData: notificationData
             - completion: returns enum result. Success case of result will return callid .failure case return error information.
     */
    public static func accept(notificationData notification:[AnyHashable : Any],rtcVideoDelegate videoDelegate:Rtc555VideoDelegate,completion: @escaping (Result<String, Error>) -> Void) {
     
         RtcReactBridge.sharedInstance.callType = "Videocall"

        let args = [notification] as [Any]
         RtcReactBridge.sharedInstance.callMethod("acceptVideo","Rtc555Video",args)
         DispatchQueue.main.async {
             Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { (timer) in
                 var result: Result<String, Error>
                if(!RtcReactBridge.sharedInstance.isBridgeInitializing){
                    let error =  NSError(domain:"", code:-901, userInfo:[ NSLocalizedDescriptionKey:"sdk not initialized"])
                    result = .failure(error)
                    completion(result)
                    timer.invalidate()
                }
                 Rtc555Logger.i("running timer")
                 if Rtc555Video.isCallSuccess ?? false{
                    Rtc555Video.isCallSuccess = false
                    result = .success(Rtc555Video.self.callId!)
                     RtcReactBridge.sharedInstance.callDelegateMap[Rtc555Video.self.callId!] = videoDelegate
                    completion(result)
                    timer.invalidate()
                  }else if Rtc555Video.isCallFailed ?? false{
                    Rtc555Video.isCallFailed = false
                    result = .failure(Rtc555Video.self.sessionError!)
                    completion(result)
                    timer.invalidate()
                  }
              }
         }
     }
    /**
       This method is called to createstream
       - Parameters:
            - callType: calltype
    */
    public static func createStream(callType calltype:String,rtcVideoDelegate videoDelegate:Rtc555VideoDelegate){
       let streamConfig = ["callType": calltype]
       rtcVideoDelegate = videoDelegate
       let args = [streamConfig]
       RtcReactBridge.sharedInstance.callMethod("createStream","Rtc555Video",args)
    }
    /**
       This method is called to close session
       - Parameters:
            - callId: call id of session
    */
    public static func hangup(callId callid:String) {
        let args = [callid]
        RtcReactBridge.sharedInstance.callMethod("hangup","Rtc555Video",args)
    }
}

/**
* Rtc555VideoDelegate is used to send callbacks for video call
*/
public protocol Rtc555VideoDelegate:Rtc555CallDelegate {
    /**
      onLocalStream is called when local stream is created
     - Parameters:
          - streamId: local stream id
    */
    func onLocalStream(streamId mediastreamId: String)
    /**
      onRemoteStream is called when remoestream is received
     - Parameters:
          - streamId: remote stream id
    */
    func onRemoteStream(streamId mediastreamId: String)
}



