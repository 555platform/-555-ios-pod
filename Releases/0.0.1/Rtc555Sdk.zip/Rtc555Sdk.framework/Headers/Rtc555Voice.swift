//
//  Rtc555Voice.swift
//  Rtc555Sdk
//
//  Created by Girish on 05/03/20.
//  Copyright © 2020 Admin. All rights reserved.
//

import Foundation

/** These are the different call status
*/
public enum CallStatus{
    /** When the call is initializing
    */
    case initializing
    /** When the call is connecting
    */
    case connecting
    /** When the call is connected
    */
    case connected
    /** When the call is disconnected
    */
    case disconnected
    /** When the call is hold
    */
    case hold
}

/**
* Input for DTMF tone during audio call.
*/
public enum DtmfInputType : String{
    case Number1 = "1"
    case Number2 = "2"
    case Number3 = "3"
    case Number4 = "4"
    case Number5 = "5"
    case Number6 = "6"
    case Number7 = "7"
    case Number8 = "8"
    case Number9 = "9"
    case Number0 = "0"
    case Star = "*"
    case Hash = "#"
    case LetterA = "A"
    case LetterB = "B"
    case LetterC = "C"
    case LetterD = "D"
    
}

/**
* The ``Rtc555Voice`` is a class used to create and manage the audio call.
*
* This class provides the following apis
*
* 1) creating the pstn session : api
 dial(targetNumber,notificationPayload)  can be used for creating session.creating session  involves in getting the room Id from  backend by REST API call and creates session using room id.
*
* 2) joining the pstn session : api  accept(notificationData)  can be used for joining session.Joining session  involves in joining the room using room id which is recieved in notification.
*
*  3) api reject(notificationData) can be used to reject incoming call

* 4)  api hold(callId) will be used to holde the call
*
* 5)  api unhold(callId) will be used to unhold the call
*
* 6)  api mute(callId) will be used to mute local stream.
 
* 7)  api ummute(callId) will be used to unmute local stream.
 
* 8) api merge(callId) will be used in merging the active session with session on hold
 
* 9)  api sendDTMF(dtmfTone) will be used to send dtmftones
*
* 10)  api hangup(callId)  used to close session
*/

public class Rtc555Voice: NSObject {
    
    static var callId:String?
    /**
    * Delegate object of Rtc555VoiceDelegate to receive  callbacks
    */
   // public static var rtcVoiceDelegate : Rtc555VoiceDelegate!
    static var isCallSuccess:Bool?
    static var isCallFailed:Bool?
    static var sessionError:Error?
    
    /**
      This method is called to create and start pstn/audio session which involves getting the room id from server and creating the room using the room id.
      - Parameters:
           - targetTelephoneNumber : telephone number of participant
           - notificationPayload: notificationData
           - completion: returns enum result. Success case of result will return callid .failure case return error information.
    */
    public static func dial(targetTelephoneNumber targetNumber:String,notificationPayload payload:String,rtcVoiceDelegate voiceDelegate:Rtc555VoiceDelegate, completion: @escaping (Result<String, Error>) -> Void) {
        
       let args = [targetNumber,payload] as [Any]
        
       RtcReactBridge.sharedInstance.callMethod("dial","Rtc555Voice",args)

       Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (timer) in
            var result: Result<String, Error>
            if(!RtcReactBridge.sharedInstance.isBridgeInitializing){
                let error =  NSError(domain:"", code:-901, userInfo:[ NSLocalizedDescriptionKey:"sdk not initialized"])
                result = .failure(error)
                completion(result)
                timer.invalidate()
            }
            
            Rtc555Logger.i("running timer")
           if Rtc555Voice.isCallSuccess ?? false{
              Rtc555Voice.isCallSuccess = false
              result = .success(Rtc555Voice.self.callId!)
              RtcReactBridge.sharedInstance.callDelegateMap[Rtc555Voice.self.callId!] = voiceDelegate
              completion(result)
              timer.invalidate()
            }else if Rtc555Voice.isCallFailed ?? false{
              Rtc555Voice.isCallFailed = false
              result = .failure(Rtc555Voice.self.sessionError!)
              completion(result)
              timer.invalidate()
            }
       }
    }
    
    /**
     This method is called to join pstn/audio session which involves joining the room using the room id recieved in notification.
      - Parameters:
           - notificationData: notificationData
           - completion: returns enum result. Success case of result will return callid .failure case return error information.
    */
    public static func accept(notificationData notification:[AnyHashable : Any],rtcVoiceDelegate voiceDelegate:Rtc555VoiceDelegate,completion: @escaping (Result<String, Error>) -> Void) {

        let args = [notification] as [Any]
        RtcReactBridge.sharedInstance.callMethod("accept","Rtc555Voice",args)
        
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (timer) in
            var result: Result<String, Error>
            if(!RtcReactBridge.sharedInstance.isBridgeInitializing){
                let error =  NSError(domain:"", code:-901, userInfo:[ NSLocalizedDescriptionKey:"sdk not initialized"])
                result = .failure(error)
                completion(result)
                timer.invalidate()
            }
            Rtc555Logger.i("running timer")
            if Rtc555Voice.isCallSuccess ?? false{
               Rtc555Voice.isCallSuccess = false
               RtcReactBridge.sharedInstance.callDelegateMap[Rtc555Voice.self.callId!] = voiceDelegate
               result = .success(Rtc555Voice.self.callId!)
               completion(result)
               timer.invalidate()
             }else if Rtc555Voice.isCallFailed ?? false{
               Rtc555Voice.isCallFailed = false
               result = .failure(Rtc555Voice.self.sessionError!)
               completion(result)
               timer.invalidate()
             }
         }
    }
    
    /**
     This method is called to reject incoming call.
      - Parameters:
           - notificationData: notificationData
           - completion: returns enum result. Success case of result will return callid .failure case return error information.
    */
    public static func reject(notificationData notification:[AnyHashable : Any],completion: @escaping (Result<String, Error>) -> Void) {
         let args = [notification]
         RtcReactBridge.sharedInstance.callMethod("reject","Rtc555Voice",args)
    
         Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (timer) in
            var result: Result<String, Error>
            if(!RtcReactBridge.sharedInstance.isBridgeInitializing){
                let error =  NSError(domain:"", code:-901, userInfo:[ NSLocalizedDescriptionKey:"sdk not initialized"])
                result = .failure(error)
                completion(result)
                timer.invalidate()
            }
            Rtc555Logger.i("running timer")
            if Rtc555Voice.isCallSuccess ?? false{
               Rtc555Voice.isCallSuccess = false
               result = .success(Rtc555Voice.self.callId!)
               completion(result)
               timer.invalidate()
           }else if Rtc555Voice.isCallFailed ?? false{
               Rtc555Voice.isCallFailed = false
               result = .failure(Rtc555Voice.self.sessionError!)
               completion(result)
               timer.invalidate()
           }
        }
    }
    
    /**
    * This method is called to hold the pstn session
     - Parameters:
          - callId: call id of pstn session
    */
    public static func hold(callId callid:String) {
           let args = [callid]
           RtcReactBridge.sharedInstance.callMethod("hold","Rtc555Voice",args)
    }
    /**
    * This method is called to unhold the pstn session
     - Parameters:
          - callId: call id of pstn session
    */
    public static func unhold(callId callid:String) {
           let args = [callid]
           RtcReactBridge.sharedInstance.callMethod("unhold","Rtc555Voice",args)
    }
    /**
    * This method is called to mute local stream of the pstn session
     - Parameters:
          - callId: call id of pstn session
    */
    public static func mute(callId callid:String) {
           let args = [callid]
           RtcReactBridge.sharedInstance.callMethod("mute","Rtc555Voice",args)
    }
    /**
    * This method is called to umute local stream of  the pstn session
     - Parameters:
          - callId: call id of pstn session
    */
    public static func unmute(callId callid:String) {
           let args = [callid]
           RtcReactBridge.sharedInstance.callMethod("unmute","Rtc555Voice",args)
    }
    /**
    * This method is called to merge the active session with the held session for PSTN call.
     - Parameters:
          - callId: call id of held pstn session
    */
    public static func merge(callId callid:Any) {
           let args = [callid]
           RtcReactBridge.sharedInstance.callMethod("merge","Rtc555Voice",args)
    }
    /**
    * This method is called to send dtmf tones
     - Parameters:
          - dtmfTone: tone
    */
    public static func sendDTMF(dtmfTone tone:DtmfInputType) {
           let args = [tone.rawValue]
           RtcReactBridge.sharedInstance.callMethod("sendDTMF","Rtc555Voice",args)
    }
    /**
    * This method is called to hangup the pstn session
     - Parameters:
          - callId: call id of pstn session
    */
    public static func hangup(callId callid:String) {
           let args = [callid]
           RtcReactBridge.sharedInstance.callMethod("hangup","Rtc555Voice",args)
    }

    /**
    * This method is called to initialize the manual audio.
     - Parameters:
          - audiomanual: boolean to enable manual audio
    */
    public static func initializeManualAudio(audioManual audiomanual:Bool) {
           let args = [audiomanual]
           RtcReactBridge.sharedInstance.callMethod("initializeManualAudio","Rtc555Voice",args)
    }
    /**
    * This method is called to enable audio. This method is  used to enable audio when audiounit is intialzed to manual using initializeManualAudio method.
     - Parameters:
          - enableaudio: boolean to enable  audio
    */
    public static func enableAudio(enableAudio enableaudio:Bool) {
           let args = [enableaudio]
           RtcReactBridge.sharedInstance.callMethod("enableAudio","Rtc555Voice",args)
    }

}

/**
* Rtc555VoiceDelegate is used to send callbacks for voice call
*/
public protocol Rtc555VoiceDelegate : Rtc555CallDelegate {
    /**
    * onCallMerged is called when call is merged
    */
    func onCallMerged(id callId:String)
}

extension  Rtc555VoiceDelegate  {
    
    func onCallMerged(id callId:String){
        
    }
}
